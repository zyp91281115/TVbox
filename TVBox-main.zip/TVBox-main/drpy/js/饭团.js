var rule={
    title:'饭团',
    模板:'首图',
    host:'https://fositv.com',
    url:'/vod____type/fyclass-fypage.html',
    二级:{"title":".text-fff&&Text;.myui-player__data p&&Text","img":"","desc":".myui-player__data p&&Text;;;.text-collapse p:eq(1)&&Text;.text-collapse p:eq(0)&&Text","content":".data&&Text","tabs":".nav-tabs:eq(0) li","lists":".myui-content__list:eq(#id) li"},
    searchUrl:'/vod_search/-------------.html?wd=**',
}